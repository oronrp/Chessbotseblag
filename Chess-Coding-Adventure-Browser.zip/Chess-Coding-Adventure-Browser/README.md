# Chess Coding Adventure — Browser Edition

A browser UI around Sebastian Lague's Chess Coding Adventure v2.0 UCI engine.

## What is preserved

The original `Engine/Core` source is copied directly from the uploaded v2.0 repository. The browser adapter adds a legal-move UI, FEN/game handling, opening-book access, and a fixed-depth browser entry point.

## Run locally

Install the .NET 8 SDK, then:

```bash
dotnet run
```

Open the local URL printed by ASP.NET.

## GitHub Pages

Push this folder to a GitHub repository. The included GitHub Actions workflow builds the Blazor WebAssembly app and deploys `wwwroot` to GitHub Pages.

## Important browser limitation

The original UCI program uses a dedicated search thread and a timer. A normal single-threaded WebAssembly page cannot use that exact process/thread model. The engine search algorithm itself is preserved, while the browser adapter searches to a selected fixed depth instead. The page is busy while the synchronous search runs.

## License

Sebastian Lague's original project is MIT licensed. The original source and attribution should remain with the project.

## GitHub Pages URL

After the workflow completes, GitHub will show the deployed Pages URL under the workflow/environment. The workflow automatically adjusts the Blazor base path for a repository Pages site.
