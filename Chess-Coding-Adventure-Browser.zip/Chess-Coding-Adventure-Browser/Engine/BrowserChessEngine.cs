using Chess.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace CodingAdventureBot;

public sealed class BrowserChessEngine
{
    private readonly Board board;
    private readonly Searcher searcher;
    private readonly OpeningBook book;

    public BrowserChessEngine()
    {
        board = Board.CreateBoard();
        searcher = new Searcher(board);
        using Stream? stream = Assembly.GetExecutingAssembly()
            .GetManifestResourceStream("ChessCodingAdventure.Book.txt");
        if (stream == null)
            throw new InvalidOperationException("Opening book resource was not found.");

        using StreamReader reader = new(stream);
        book = new OpeningBook(reader.ReadToEnd());
    }

    public Board Board => board;

    public void NewGame() => board.LoadPosition(FenUtility.StartPositionFEN);

    public void SetPosition(string fen) => board.LoadPosition(fen);

    public IReadOnlyList<string> GetLegalMoves()
    {
        MoveGenerator generator = new();
        Span<Move> moves = stackalloc Move[256];
        generator.GenerateMoves(board, ref moves, capturesOnly: false);

        List<string> result = new(moves.Length);
        for (int i = 0; i < moves.Length; i++)
            result.Add(MoveUtility.GetMoveNameUCI(moves[i]).Replace("=", ""));
        return result;
    }

    public bool MakeMove(string uci)
    {
        Move move = MoveUtility.GetMoveFromUCIName(uci, board);
        if (move.IsNull)
            return false;

        Span<Move> legalMoves = stackalloc Move[256];
        MoveGenerator generator = new();
        generator.GenerateMoves(board, ref legalMoves, capturesOnly: false);

        for (int i = 0; i < legalMoves.Length; i++)
        {
            if (MoveUtility.GetMoveNameUCI(legalMoves[i]).Replace("=", "") == uci)
            {
                board.MakeMove(legalMoves[i]);
                return true;
            }
        }

        return false;
    }

    public string Think(int depth)
    {
        // Preserve the repository's opening book behaviour for the first 16 plies.
        if (board.PlyCount <= 16 &&
            book.TryGetBookMove(board, out string bookMove))
        {
            MakeMove(bookMove);
            return bookMove;
        }

        searcher.SearchToDepth(depth);
        Move best = searcher.BestMoveSoFar;
        string move = MoveUtility.GetMoveNameUCI(best).Replace("=", "");
        if (!best.IsNull)
            board.MakeMove(best);
        return move;
    }

    public bool IsInCheck() => board.IsInCheck();

    public bool IsGameOver(out string result)
    {
        MoveGenerator generator = new();
        Span<Move> moves = stackalloc Move[256];
        generator.GenerateMoves(board, ref moves, capturesOnly: false);

        if (moves.Length == 0)
        {
            result = board.IsInCheck()
                ? (board.IsWhiteToMove ? "Checkmate — Black wins" : "Checkmate — White wins")
                : "Draw — stalemate";
            return true;
        }

        if (board.FiftyMoveCounter >= 100)
        {
            result = "Draw — 50-move rule";
            return true;
        }

        result = "";
        return false;
    }

    public string CurrentFen => FenUtility.CurrentFen(board);
    public int PlyCount => board.PlyCount;
    public bool WhiteToMove => board.IsWhiteToMove;
}
